export const environment = {
    production: false,
    firebaseConfig : {
    apiKey: "AIzaSyAHEgTZ79QqK6vj3leDkqZ3XeaR6AF1s-E",
    authDomain: "a2p2rescuepetsproject.firebaseapp.com",
    projectId: "a2p2rescuepetsproject",
    storageBucket: "a2p2rescuepetsproject.appspot.com",
    messagingSenderId: "346831606404",
    appId: "1:346831606404:web:11a5c8834b6cf6905228d1"
    }
};
