export interface Shelter {
  id?:string;
  name:string;
  history:Array<string>;
  location:string;
  contact:Array<any>;
  images:Array<any>;
  mapsURL:string;
}

