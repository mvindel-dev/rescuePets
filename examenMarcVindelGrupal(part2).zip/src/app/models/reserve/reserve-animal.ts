export interface ReserveAnimal {
    reserva_id:string;
    volunteer_id:string;
    animal_id:string;
    day:string;
    hour:number;
}
